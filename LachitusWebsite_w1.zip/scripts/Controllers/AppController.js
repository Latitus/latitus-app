/**
 * Created by phaml_000 on 12/8/2015.
 */
App.controller('AppController', function ($state) {
    $state.go('lachitus.home');
});